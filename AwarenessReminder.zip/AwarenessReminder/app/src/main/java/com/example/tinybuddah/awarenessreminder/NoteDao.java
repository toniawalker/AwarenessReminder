package com.example.tinybuddah.awarenessreminder;

import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

import static android.icu.text.MessagePattern.ArgType.SELECT;

/**
 * Created by tiny buddah on 4/3/2018.
 */

public interface NoteDao {
    @Query(SELECT * FROM user Note)
    List<Note> getAll();

    @Insert
    void insert(Note note);

    @Update
    void update(Note note);

    @Delete
    void delete(Note note);
}
