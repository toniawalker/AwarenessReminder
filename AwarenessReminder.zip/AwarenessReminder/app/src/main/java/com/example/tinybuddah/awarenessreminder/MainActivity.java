package com.example.tinybuddah.awarenessreminder;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
implements TextView.OnEditorActionListener, View.OnClickListener {
    //define variable for the widgets
    private EditText nameEditText;
    private TextView quoteTextView;
    private Button journalButton;
    private Button activityButton;
    private Button milestoneButton;
    private Button meditateButton;


    //define Shared Preference object
    private SharedPreferences savedValues;

    private String name = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get references to the widgets
        nameEditText = (EditText) findViewById(R.id.nameEditText);
        journalButton = (Button) findViewById(R.id.journalButton);
        activityButton = (Button) findViewById(R.id.activityButton);
        milestoneButton = (Button) findViewById(R.id.milestoneButton);
        quoteTextView = (TextView) findViewById(R.id.quoteTextView);
        meditateButton = (Button) findViewById(R.id.meditateButton);

        //set the listeners
        nameEditText.setOnEditorActionListener(this);
        journalButton.setOnClickListener(this);
        activityButton.setOnClickListener(this);
        milestoneButton.setOnClickListener(this);
        quoteTextView.setOnClickListener(this);
        meditateButton.setOnClickListener(this);

        //get Shared Prefernce object
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    //@Override
    public boolean onOptionsItemsSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.activity_main:
                startActivity(new Intent(getApplicationContext(),
                        MainActivity.class));
                return true;
            case R.id.meditate:
                startActivity(new Intent(getApplicationContext(),
                        Meditation.class));
                return true;
            case R.id.timer:
                startActivity(new Intent(getApplicationContext(),
                        Timer.class));
                return true;
            case R.id.alarm:
                startActivity(new Intent(getApplicationContext(),
                        Alarm.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public void onPause() {
        //save the instance variable
        SharedPreferences.Editor editor = savedValues.edit();
        editor.putString("name", name);
        editor.commit();

        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();

        //get the instance variable
        name = savedValues.getString("name", "");

        //set the name on its widget
        nameEditText.setText(name);

        //display
        displayName();
    }

    public void displayName() {
        name = nameEditText.getText().toString();
    }

    @Override
    public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        if (i == EditorInfo.IME_ACTION_DONE) {
            displayName();
        }
        return false;
    }

    @Override
    public void onClick(View view) {
        //switch (view.getId()){
        Intent intent = new Intent(view.getContext(), Meditation.class);
        startActivity(intent);
        //case R.id.meditate:
        //   displayName();
        //   break;
    }
}

