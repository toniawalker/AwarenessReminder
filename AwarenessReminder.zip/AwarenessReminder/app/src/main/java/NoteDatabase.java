import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.example.tinybuddah.awarenessreminder.Note;

/**
 * Created by tiny buddah on 4/3/2018.
 */

@Database(entities = (Note.class), version = 1)
public abstract class NoteDatabase extends RoomDatabase {
    private static NoteDatabase note_instance;

    public static NoteDatabase GetInstance(Context context) {
        if (note_instance == null) {
            note_instance = createInstamce(context);
        }
        return note_instance;
    }

    public static NoteDatabase createInstamce(Context context) {
        NoteDatabase newDatabase = Room.databaseBuilder(context, NoteDatabase.class, "Note")
                .allowMainThreadQueries().build();
    }

}
